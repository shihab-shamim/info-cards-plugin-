
export const data = {
    imageSlider: {
        items: [
            {
                title: "Default",
                img: "https://templates.bplugins.com/wp-content/uploads/2025/06/default.png",
                link: "https://b-slider.bplugins.com/demo/default/"
            }
        ]
    },
    posts: {

        items: [
            {
                title: "Posts default layout",
                img: "https://templates.bplugins.com/wp-content/uploads/2025/06/b-slider-posts-default-layout.png",
                link: "https://b-slider.bplugins.com/demo/posts-default-layout/"
            },
            
        ]
    },
     
     
}