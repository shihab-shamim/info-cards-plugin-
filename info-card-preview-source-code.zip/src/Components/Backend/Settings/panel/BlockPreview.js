import React, { useState } from "react";
import { Button, Popover } from "@wordpress/components";
import "./style.scss";
const BlockPreview = ({
  options,
  value,
  onChange,
  isPremium,
  setAttributes,
  isExistingData
}) => {
  const [activeIndex, setActiveIndex] = useState(null);

  const handleButtonClick = (blockValue, idx) => {
    onChange(blockValue);
    setActiveIndex(idx);
    handleBlockReplace(blockValue);

   
    // !isExistingData?setDefaultData(): setDemoData();
  };
  const handleMouseInteraction = (idx, isEnter) => {
    setActiveIndex(isEnter ? idx : null);
  };
  const handleBlockReplace = (blockContent) => {
    onChange(blockContent);
  };

  const setDefaultData = (blockValue, idx) => {
    handleButtonClick(blockValue, idx)
    setAttributes({ isExistingData: true });
  };

  const setDemoData = (blockValue, idx) => {
    handleButtonClick(blockValue, idx)
    setAttributes({ isExistingData: false });
  };

  return (
    <div className="bPlBlockPreviewWrapper">
      {options?.map((theme, idx) => (
        <div key={idx}>
          <div>
            <Button
              className={`bPl-previewBtn ${
                value === theme.value ? "bPl-activeBtn" : ""
              }`}
              // onClick={() => handleButtonClick(theme.value, idx, theme.content)}
              onClick={
                !theme?.isPro
                  ? () => handleButtonClick(theme.value, idx, theme.content)
                  : undefined
              }
              onMouseEnter={() => handleMouseInteraction(idx, true)}
              onMouseLeave={() => handleMouseInteraction(idx, false)}
            >
              <span className="bplOpacity75">{theme.label}</span>
              {theme?.isPro && !isPremium && (
                <span
                  className={`labelPro 
 ${value === theme.value ? "labelProActive" : ""}`}
                >
                  Pro
                </span>
              )}
            </Button>
          </div>
          {activeIndex === idx && (
            <Popover
              style={{ cursor: "pointer" }}
              // onClick={() => handleButtonClick(theme.value, idx, theme.content)}
            >
              <div
                onMouseEnter={() => handleMouseInteraction(idx, true)}
                onMouseLeave={() => handleMouseInteraction(idx, false)}
                style={{ height: theme.height, width: theme.width }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    padding: "10px",
                  }}
                >
                  {theme?.isPro && isPremium && (
                    <button
                    onClick={() =>
                        // handleButtonClick(theme.value, idx, theme.content)
                        setDefaultData(theme.value, idx, theme.content)
                      }
                      style={{
                        padding: "8px 16px",
                        backgroundColor: "#4527A4",
                        color: "#fff",
                        border: "none",
                        borderRadius: "2px",

                        cursor: "pointer",
                        boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                      }}
                    >
                      Import With Default Data
                    </button>
                  )}

                  {theme?.isPro && (
                    <button
                      onClick={() =>
                        setDemoData(theme.value, idx, theme.content)
                      }
                      style={{
                        padding: "8px 16px",
                        backgroundColor: "#006BA1",
                        color: "#fff",
                        border: "none",
                        borderRadius: "2px",
                        cursor: "pointer",
                        boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                      }}
                    >
                      Import With Demo Data
                    </button>
                  )}
                </div>
                <img
                  src={theme.img}
                  style={{
                    minHeight: "100%",
                    width: "100%",
                    objectFit: "contain",
                  }}
                />
              </div>
            </Popover>
          )}
        </div>
      ))}
    </div>
  );
};
export default BlockPreview;
