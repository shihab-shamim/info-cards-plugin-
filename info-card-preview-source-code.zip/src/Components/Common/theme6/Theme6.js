import Card from "./Card";

const Theme6 = ({setAttributes,attributes,isBacked,premiumProps}) => {
    const {cards,isExistingData,productsInfo}=attributes;
    

    
    return (
        <div className="productInfoCards">
           

            {/* {cards.map(((item)) => {
                 <Card />
                
            })} */}
            {
                //  cards.map((item,index)=><Card key={index} item={item} index={index} attributes={attributes} setAttributes={setAttributes} isBacked={isBacked} premiumProps={premiumProps} />)

                isExistingData?cards.map((item,index)=><Card key={index} item={item} index={index} attributes={attributes} setAttributes={setAttributes} isBacked={isBacked} premiumProps={premiumProps} />):productsInfo.map((item,index)=><Card key={index} item={item} index={index} attributes={attributes} setAttributes={setAttributes} isBacked={isBacked} premiumProps={premiumProps} />)
            }

           
            
        </div>
    );
};

export default Theme6;